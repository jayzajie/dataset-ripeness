.. code:: ipython3

    import tensorflow as tf
    import pandas as pd
    import numpy as np
    import cv2
    import os
    from tensorflow.keras.preprocessing.image import ImageDataGenerator
    from tensorflow.keras import layers, models, optimizers
    from tensorflow.keras.optimizers import Adam
    import shutil
    import matplotlib.pyplot as plt

.. code:: ipython3

    # Direktori dataset
    base_dir = r'C:\New Datasets'
    
    # Ukuran gambar sesuai MobileNetV2
    IMG_SIZE = (224, 224)
    BATCH_SIZE = 32
    
    # Membagi dataset menjadi train dan validasi (80:20)
    raw_train_dataset = tf.keras.utils.image_dataset_from_directory(
        base_dir,
        validation_split=0.2,  # 20% data untuk validasi
        subset="training",
        seed=123,  # Seed untuk hasil yang konsisten
        image_size=IMG_SIZE,
        batch_size=BATCH_SIZE
    )
    
    raw_validation_dataset = tf.keras.utils.image_dataset_from_directory(
        base_dir,
        validation_split=0.2,  # 20% data untuk validasi
        subset="validation",
        seed=123,
        image_size=IMG_SIZE,
        batch_size=BATCH_SIZE
    )
    
    # Normalisasi nilai piksel
    normalization_layer = tf.keras.layers.Rescaling(1./255)
    train_dataset = raw_train_dataset.map(lambda x, y: (normalization_layer(x), y))
    validation_dataset = raw_validation_dataset.map(lambda x, y: (normalization_layer(x), y))
    
    # Prefetch untuk mempercepat loading data
    AUTOTUNE = tf.data.AUTOTUNE
    train_dataset = train_dataset.prefetch(buffer_size=AUTOTUNE)
    validation_dataset = validation_dataset.prefetch(buffer_size=AUTOTUNE)
    
    # Informasi untuk pengguna
    print(f"Total batch untuk training: {len(train_dataset)}")
    print(f"Total batch untuk validasi: {len(validation_dataset)}")
    
    # Dapatkan nama kelas dari dataset asli
    train_classes = raw_train_dataset.class_names
    valid_classes = raw_validation_dataset.class_names
    
    print("\nJumlah class di train:", len(train_classes))
    print("List class di train:", train_classes)
    
    print("\nJumlah class di valid:", len(valid_classes))
    print("List class di valid:", valid_classes)
    
    


.. parsed-literal::

    Found 14157 files belonging to 14 classes.
    Using 11326 files for training.
    Found 14157 files belonging to 14 classes.
    Using 2831 files for validation.
    Total batch untuk training: 354
    Total batch untuk validasi: 89
    
    Jumlah class di train: 14
    List class di train: ['RipeApple', 'RipeBanana', 'RipeGrape', 'RipeGuava', 'RipeOrange', 'RipePomegranate', 'RipeStrawberry', 'UnripeApple', 'UnripeBanana', 'UnripeGrape', 'UnripeGuava', 'UnripeOrange', 'UnripePomegranate', 'UnripeStrawberry']
    
    Jumlah class di valid: 14
    List class di valid: ['RipeApple', 'RipeBanana', 'RipeGrape', 'RipeGuava', 'RipeOrange', 'RipePomegranate', 'RipeStrawberry', 'UnripeApple', 'UnripeBanana', 'UnripeGrape', 'UnripeGuava', 'UnripeOrange', 'UnripePomegranate', 'UnripeStrawberry']
    

.. code:: ipython3

    # Preprocessing untuk gambar (grayscale dan normalisasi)
    def preprocess_image(img, label):
        # Resize gambar ke ukuran yang diinginkan
        img = tf.image.resize(img, IMG_SIZE)
        # Ubah gambar menjadi grayscale
        img = tf.image.rgb_to_grayscale(img)
        # Normalisasi nilai piksel
        img = img / 255.0
        return img, label
    
    # Augmentasi untuk gambar pada dataset training
    def augment_image(img, label):
        # Random flip
        img = tf.image.random_flip_left_right(img)
        img = tf.image.random_flip_up_down(img)
        # Random brightness dan contrast
        img = tf.image.random_brightness(img, max_delta=0.2)
        img = tf.image.random_contrast(img, lower=0.8, upper=1.2)
        # Random zoom (crop and resize)
        zoom = tf.random.uniform([], 0.8, 1.2)
        img = tf.image.central_crop(img, central_fraction=zoom)
        img = tf.image.resize(img, IMG_SIZE)
        return img, label
    
    # Preprocessing dan augmentasi untuk dataset training
    train_dataset_final = (
        train_dataset
        .map(preprocess_image, num_parallel_calls=tf.data.AUTOTUNE)
        .map(augment_image, num_parallel_calls=tf.data.AUTOTUNE)  # Augmentation if needed
        .prefetch(buffer_size=tf.data.AUTOTUNE)
    )
    
    validation_dataset_final = (
        validation_dataset
        .map(preprocess_image, num_parallel_calls=tf.data.AUTOTUNE)
        .prefetch(buffer_size=tf.data.AUTOTUNE)
    )

.. code:: ipython3

    import matplotlib.pyplot as plt
    import random
    import os
    import tensorflow as tf
    import cv2
    
    def visualize_preprocessing(image_path):
        # Load the original image
        original_img = tf.keras.preprocessing.image.load_img(image_path, target_size=(224, 224))
        original_img_array = tf.keras.preprocessing.image.img_to_array(original_img)
    
        # Preprocess the image to grayscale
        gray_image = cv2.cvtColor(original_img_array, cv2.COLOR_BGR2GRAY)
        gray_image = cv2.cvtColor(gray_image, cv2.COLOR_GRAY2BGR)
    
        # Plot the original and preprocessed images
        fig, axes = plt.subplots(1, 2, figsize=(10, 5))  # Fixed from 'pl' to 'plt'
    
        axes[0].imshow(tf.keras.preprocessing.image.array_to_img(original_img_array))
        axes[0].set_title("Original Image")
        axes[0].axis('off')
    
        axes[1].imshow(tf.keras.preprocessing.image.array_to_img(gray_image))
        axes[1].set_title("Grayscale Image")
        axes[1].axis('off')
    
        plt.show()
    
    def get_random_image_path(directory):
        all_files = []
        for root, dirs, files in os.walk(directory):
            for file in files:
                if file.lower().endswith(('.png', '.jpg', '.jpeg')):
                    all_files.append(os.path.join(root, file))
        return random.choice(all_files) if all_files else None
    
    # Example usage
    random_image_path = get_random_image_path(r'C:\New Datasets')
    if random_image_path:
        visualize_preprocessing(random_image_path)
    else:
        print("No images found in the directory")
    



.. image:: output_3_0.png


.. code:: ipython3

    import tensorflow as tf
    import random
    import matplotlib.pyplot as plt
    import os
    
    # Assuming IMG_SIZE, BATCH_SIZE, train_dataset, and validation_dataset are already defined
    def preprocess_image(img, label):
        # Convert image to RGB if it's grayscale
        if img.shape[-1] != 3:  # If the image has 1 channel (grayscale)
            img = tf.image.grayscale_to_rgb(img)  # Convert grayscale to RGB
        
        # Resize the image
        img = tf.image.resize(img, IMG_SIZE)  # Resize to (224, 224)
        
        # Normalize the image to [0, 1]
        img = img / 255.0
        return img, label
    
    
    
    
    # Load and preprocess image function
    def load_and_preprocess_image(image_path):
        img = tf.keras.preprocessing.image.load_img(image_path, target_size=IMG_SIZE)
        img_array = tf.keras.preprocessing.image.img_to_array(img)
        grayscale_img, _ = preprocess_image(img_array, None)  # Only use the image for processing, no label
        return img_array, grayscale_img
    
    # Show original and grayscale images
    def show_images(image_paths, class_names, num_images=5):
        plt.figure(figsize=(20, 10))
    
        for i in range(num_images):
            image_path = image_paths[i]
            original_img, grayscale_img = load_and_preprocess_image(image_path)
    
            # Display original image
            plt.subplot(2, num_images, i + 1)
            plt.imshow(tf.keras.preprocessing.image.array_to_img(original_img))
            plt.title(f"Original - {class_names[i]}")
            plt.axis('off')
    
            # Display grayscale image
            plt.subplot(2, num_images, num_images + i + 1)
            plt.imshow(tf.keras.preprocessing.image.array_to_img(grayscale_img))
            plt.title(f"Grayscale - {class_names[i]}")
            plt.axis('off')
    
        plt.show()
    
    # Function to get random image paths and their class names
    def get_random_image_paths_and_classes(directory, num_images=5):
        image_paths = []
        class_names = []
    
        for class_name in os.listdir(directory):
            class_dir = os.path.join(directory, class_name)
            if os.path.isdir(class_dir):
                images = os.listdir(class_dir)
                random.shuffle(images)
                selected_images = images[:num_images]  # Select a few random images
                image_paths.extend([os.path.join(class_dir, img) for img in selected_images])
                class_names.extend([class_name] * num_images)
    
        return image_paths, class_names
    
    # Example usage:
    train_dataset_dir = r'C:\New Datasets'  # Path to your dataset directory
    num_images = 5  # Number of random images to visualize
    
    # Get random image paths and their class names
    image_paths, class_names = get_random_image_paths_and_classes(train_dataset_dir, num_images)
    
    # Show images
    show_images(image_paths, class_names, num_images)
    



.. image:: output_4_0.png


.. code:: ipython3

    # Define MobileNetV2 base model
    base_model = tf.keras.applications.MobileNetV2(input_shape=IMG_SIZE + (3,),
                                                   include_top=False,
                                                   weights='imagenet')
    
    base_model.trainable = True
    for layer in base_model.layers[:-20]:
        layer.trainable = False
    
    # Define the full model
    model = models.Sequential([
        base_model,
        layers.GlobalAveragePooling2D(),
        layers.Dense(1024, activation='relu'),
        layers.BatchNormalization(),
        layers.Dropout(0.5),
        layers.Dense(512, activation='relu'),
        layers.BatchNormalization(),
        layers.Dropout(0.3),
        layers.Dense(256, activation='relu'),
        layers.BatchNormalization(),
        layers.Dropout(0.1),
        layers.Dense(len(raw_train_dataset.class_names), activation='softmax')
    ])
    
    model.compile(optimizer=Adam(learning_rate=0.001),
                  loss=tf.keras.losses.SparseCategoricalCrossentropy(from_logits=False),
                  metrics=['accuracy'])
    
    model.summary()
    



.. raw:: html

    <pre style="white-space:pre;overflow-x:auto;line-height:normal;font-family:Menlo,'DejaVu Sans Mono',consolas,'Courier New',monospace"><span style="font-weight: bold">Model: "sequential_7"</span>
    </pre>
    



.. raw:: html

    <pre style="white-space:pre;overflow-x:auto;line-height:normal;font-family:Menlo,'DejaVu Sans Mono',consolas,'Courier New',monospace">┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━┓
    ┃<span style="font-weight: bold"> Layer (type)                    </span>┃<span style="font-weight: bold"> Output Shape           </span>┃<span style="font-weight: bold">       Param # </span>┃
    ┡━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━┩
    │ mobilenetv2_1.00_224            │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">7</span>, <span style="color: #00af00; text-decoration-color: #00af00">7</span>, <span style="color: #00af00; text-decoration-color: #00af00">1280</span>)     │     <span style="color: #00af00; text-decoration-color: #00af00">2,257,984</span> │
    │ (<span style="color: #0087ff; text-decoration-color: #0087ff">Functional</span>)                    │                        │               │
    ├─────────────────────────────────┼────────────────────────┼───────────────┤
    │ global_average_pooling2d_9      │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">1280</span>)           │             <span style="color: #00af00; text-decoration-color: #00af00">0</span> │
    │ (<span style="color: #0087ff; text-decoration-color: #0087ff">GlobalAveragePooling2D</span>)        │                        │               │
    ├─────────────────────────────────┼────────────────────────┼───────────────┤
    │ dense_34 (<span style="color: #0087ff; text-decoration-color: #0087ff">Dense</span>)                │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">1024</span>)           │     <span style="color: #00af00; text-decoration-color: #00af00">1,311,744</span> │
    ├─────────────────────────────────┼────────────────────────┼───────────────┤
    │ batch_normalization_27          │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">1024</span>)           │         <span style="color: #00af00; text-decoration-color: #00af00">4,096</span> │
    │ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalization</span>)            │                        │               │
    ├─────────────────────────────────┼────────────────────────┼───────────────┤
    │ dropout_27 (<span style="color: #0087ff; text-decoration-color: #0087ff">Dropout</span>)            │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">1024</span>)           │             <span style="color: #00af00; text-decoration-color: #00af00">0</span> │
    ├─────────────────────────────────┼────────────────────────┼───────────────┤
    │ dense_35 (<span style="color: #0087ff; text-decoration-color: #0087ff">Dense</span>)                │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">512</span>)            │       <span style="color: #00af00; text-decoration-color: #00af00">524,800</span> │
    ├─────────────────────────────────┼────────────────────────┼───────────────┤
    │ batch_normalization_28          │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">512</span>)            │         <span style="color: #00af00; text-decoration-color: #00af00">2,048</span> │
    │ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalization</span>)            │                        │               │
    ├─────────────────────────────────┼────────────────────────┼───────────────┤
    │ dropout_28 (<span style="color: #0087ff; text-decoration-color: #0087ff">Dropout</span>)            │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">512</span>)            │             <span style="color: #00af00; text-decoration-color: #00af00">0</span> │
    ├─────────────────────────────────┼────────────────────────┼───────────────┤
    │ dense_36 (<span style="color: #0087ff; text-decoration-color: #0087ff">Dense</span>)                │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)            │       <span style="color: #00af00; text-decoration-color: #00af00">131,328</span> │
    ├─────────────────────────────────┼────────────────────────┼───────────────┤
    │ batch_normalization_29          │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)            │         <span style="color: #00af00; text-decoration-color: #00af00">1,024</span> │
    │ (<span style="color: #0087ff; text-decoration-color: #0087ff">BatchNormalization</span>)            │                        │               │
    ├─────────────────────────────────┼────────────────────────┼───────────────┤
    │ dropout_29 (<span style="color: #0087ff; text-decoration-color: #0087ff">Dropout</span>)            │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">256</span>)            │             <span style="color: #00af00; text-decoration-color: #00af00">0</span> │
    ├─────────────────────────────────┼────────────────────────┼───────────────┤
    │ dense_37 (<span style="color: #0087ff; text-decoration-color: #0087ff">Dense</span>)                │ (<span style="color: #00d7ff; text-decoration-color: #00d7ff">None</span>, <span style="color: #00af00; text-decoration-color: #00af00">14</span>)             │         <span style="color: #00af00; text-decoration-color: #00af00">3,598</span> │
    └─────────────────────────────────┴────────────────────────┴───────────────┘
    </pre>
    



.. raw:: html

    <pre style="white-space:pre;overflow-x:auto;line-height:normal;font-family:Menlo,'DejaVu Sans Mono',consolas,'Courier New',monospace"><span style="font-weight: bold"> Total params: </span><span style="color: #00af00; text-decoration-color: #00af00">4,236,622</span> (16.16 MB)
    </pre>
    



.. raw:: html

    <pre style="white-space:pre;overflow-x:auto;line-height:normal;font-family:Menlo,'DejaVu Sans Mono',consolas,'Courier New',monospace"><span style="font-weight: bold"> Trainable params: </span><span style="color: #00af00; text-decoration-color: #00af00">3,181,134</span> (12.14 MB)
    </pre>
    



.. raw:: html

    <pre style="white-space:pre;overflow-x:auto;line-height:normal;font-family:Menlo,'DejaVu Sans Mono',consolas,'Courier New',monospace"><span style="font-weight: bold"> Non-trainable params: </span><span style="color: #00af00; text-decoration-color: #00af00">1,055,488</span> (4.03 MB)
    </pre>
    


.. code:: ipython3

    from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping, ReduceLROnPlateau
    
    # Callback untuk menyimpan model terbaik
    checkpoint_cb = ModelCheckpoint("best_model.keras", save_best_only=True)
    
    # Calculate the number of samples from the dataset
    num_samples = tf.data.experimental.cardinality(train_dataset_final).numpy() * BATCH_SIZE
    num_epochs = 50  # Jumlah epoch yang ditentukan
    
    # Callback untuk menghentikan pelatihan jika val_accuracy > 91%
    early_stopping_cb = EarlyStopping(monitor='val_accuracy',
                                      min_delta=0.005,  # Keakuratan minimum yang dianggap sebagai peningkatan
                                      patience=7,  # Jumlah epoch untuk menunggu sebelum menghentikan
                                      mode='max',
                                      restore_best_weights=True,
                                      verbose=1)
    
    # Callback untuk mengurangi learning rate saat val_loss tidak membaik
    reduce_lr_cb = ReduceLROnPlateau(monitor='val_loss',
                                     factor=0.2,
                                     patience=3,
                                     verbose=1,
                                     min_delta=0.005,
                                     mode='min')
    
    # Melatih model dengan callbacks yang diperbarui
    history = model.fit(
        train_dataset_final,
        validation_data=validation_dataset_final,
        epochs=num_epochs,
        callbacks=[checkpoint_cb, early_stopping_cb, reduce_lr_cb]
    )
    


.. parsed-literal::

    Epoch 1/50
    

::


    ---------------------------------------------------------------------------

    ValueError                                Traceback (most recent call last)

    Cell In[75], line 27
         19 reduce_lr_cb = ReduceLROnPlateau(monitor='val_loss',
         20                                  factor=0.2,
         21                                  patience=3,
         22                                  verbose=1,
         23                                  min_delta=0.005,
         24                                  mode='min')
         26 # Melatih model dengan callbacks yang diperbarui
    ---> 27 history = model.fit(
         28     train_dataset_final,
         29     validation_data=validation_dataset_final,
         30     epochs=num_epochs,
         31     callbacks=[checkpoint_cb, early_stopping_cb, reduce_lr_cb]
         32 )
    

    File ~\anaconda3\envs\myenv\Lib\site-packages\keras\src\utils\traceback_utils.py:122, in filter_traceback.<locals>.error_handler(*args, **kwargs)
        119     filtered_tb = _process_traceback_frames(e.__traceback__)
        120     # To get the full stack trace, call:
        121     # `keras.config.disable_traceback_filtering()`
    --> 122     raise e.with_traceback(filtered_tb) from None
        123 finally:
        124     del filtered_tb
    

    File ~\anaconda3\envs\myenv\Lib\site-packages\keras\src\layers\input_spec.py:227, in assert_input_compatibility(input_spec, inputs, layer_name)
        222     for axis, value in spec.axes.items():
        223         if value is not None and shape[axis] not in {
        224             value,
        225             None,
        226         }:
    --> 227             raise ValueError(
        228                 f'Input {input_index} of layer "{layer_name}" is '
        229                 f"incompatible with the layer: expected axis {axis} "
        230                 f"of input shape to have value {value}, "
        231                 "but received input with "
        232                 f"shape {shape}"
        233             )
        234 # Check shape.
        235 if spec.shape is not None:
    

    ValueError: Exception encountered when calling Functional.call().
    
    Input 0 of layer "Conv1" is incompatible with the layer: expected axis -1 of input shape to have value 3, but received input with shape (None, 224, 224, 1)
    
    Arguments received by Functional.call():
      • inputs=tf.Tensor(shape=(None, 224, 224, 1), dtype=float32)
      • training=True
      • mask=None


